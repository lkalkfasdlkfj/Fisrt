# 部署包使用说明

## 快速开始

```bash
chmod +x server-deploy.sh
./server-deploy.sh --domain=mom.uuuakddd.top --email=wkoq212@gmail.com
```

## 部署配置

- 服务器域名: mom.uuuakddd.top
- SSL邮箱: wkoq212@gmail.com
- 创建时间: 2025-12-16T10:28:52.371Z

## 部署后地址

- 后端 API: https://mom.uuuakddd.top
- uToLuck: https://utoluck.pages.dev
- CoinToUsdt: https://cointousdt.pages.dev
- 管理后台: https://backend-admin.pages.dev

## 目录结构

```
├── backend/           # 后端服务
│   ├── cherry         # Go 二进制
│   ├── static/        # gameLogin 前端
│   ├── docker-compose.yml
│   └── Dockerfile
├── frontend/          # Cloudflare Pages 前端
│   ├── uToLuck/
│   ├── CoinToUsdt/
│   └── backendAdmin/
├── deploy-config.json # 部署配置
├── server-deploy.sh   # 部署脚本
└── README.md          # 本文件
```
