import{s as e}from"./request-CscU4O0O.js";const t=r=>e.post("/transfer/execute",r),a=r=>e.post("/transfer/batch",r),n=r=>e.get("/transfer/records",{params:r});export{a as b,t as e,n as g};
