#!/bin/bash
#===============================================================================
# 服务器端一键部署脚本
# 
# 功能：
#   1. 下载并解压部署包（如果指定了URL）
#   2. 安装 Docker（如果需要）
#   3. 部署后端服务（Docker Compose）
#   4. 部署前端到 Cloudflare Pages
#   5. 申请 SSL 证书（调用本地API，自动配置CORS）
#
# 使用方式：
#   chmod +x server-deploy.sh
#   ./server-deploy.sh --domain=api.example.com --email=admin@example.com --cf-token=xxx
#===============================================================================

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 默认配置
SERVER_DOMAIN=""
SERVER_EMAIL=""
PACKAGE_URL=""
CLOUDFLARE_API_TOKEN=""
CF_PROJECT_NAME="daou-admin"
SKIP_DOCKER="false"
SKIP_SSL="false"
SKIP_FRONTEND="false"
AUTO_YES="false"

# 部署后的真实URL
DEPLOYED_URL=""

# Docker Compose 命令
COMPOSE_CMD=""

#===============================================================================
# 工具函数
#===============================================================================

log_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

log_step() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

show_help() {
    cat << EOF
服务器端一键部署脚本

使用方式:
    ./server-deploy.sh [选项]

选项:
    --url=URL           部署包下载链接（可选）
    --domain=DOMAIN     服务器域名（用于SSL证书）
    --email=EMAIL       SSL证书邮箱
    --cf-token=TOKEN    Cloudflare API Token
    --cf-project=NAME   Cloudflare Pages 项目名（默认: daou-admin）
    --skip-docker       跳过Docker安装检查
    --skip-ssl          跳过SSL证书申请
    --skip-frontend     跳过Cloudflare Pages部署
    --yes, -y           自动确认，跳过交互提示
    --help              显示帮助信息

Cloudflare API Token 创建方法:
    1. 访问 https://dash.cloudflare.com/profile/api-tokens
    2. 点击 "Create Token"
    3. 选择 "Edit Cloudflare Workers" 模板
    4. 复制生成的 Token

示例:
    ./server-deploy.sh --domain=api.example.com --email=admin@example.com --cf-token=xxx
EOF
    exit 0
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --url=*)
                PACKAGE_URL="${1#*=}"
                ;;
            --domain=*)
                SERVER_DOMAIN="${1#*=}"
                ;;
            --email=*)
                SERVER_EMAIL="${1#*=}"
                ;;
            --cf-token=*)
                CLOUDFLARE_API_TOKEN="${1#*=}"
                ;;
            --cf-project=*)
                CF_PROJECT_NAME="${1#*=}"
                ;;
            --skip-docker)
                SKIP_DOCKER="true"
                ;;
            --skip-ssl)
                SKIP_SSL="true"
                ;;
            --skip-frontend)
                SKIP_FRONTEND="true"
                ;;
            --yes|-y)
                AUTO_YES="true"
                ;;
            --help|-h)
                show_help
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                ;;
        esac
        shift
    done
}

# 从 deploy-config.json 读取配置
load_deploy_config() {
    local config_file="$SCRIPT_DIR/deploy-config.json"
    
    if [ -f "$config_file" ]; then
        log_info "从 deploy-config.json 读取配置..."
        
        if [ -z "$SERVER_DOMAIN" ]; then
            SERVER_DOMAIN=$(grep -o '"server_domain"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
        fi
        if [ -z "$SERVER_EMAIL" ]; then
            SERVER_EMAIL=$(grep -o '"server_email"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
        fi
        if [ -z "$CLOUDFLARE_API_TOKEN" ]; then
            local cf_token_from_config=$(grep -o '"cf_token"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
            if [ -n "$cf_token_from_config" ]; then
                CLOUDFLARE_API_TOKEN="$cf_token_from_config"
            fi
        fi
        if [ -z "$CF_PROJECT_NAME" ] || [ "$CF_PROJECT_NAME" = "daou-admin" ]; then
            local cf_project_from_config=$(grep -o '"cf_project_name"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
            if [ -n "$cf_project_from_config" ]; then
                CF_PROJECT_NAME="$cf_project_from_config"
            fi
        fi
    fi
}

validate_config() {
    local missing=""
    
    if [ -z "$SERVER_DOMAIN" ]; then
        missing="$missing SERVER_DOMAIN(--domain)"
    fi
    if [ -z "$SERVER_EMAIL" ]; then
        missing="$missing SERVER_EMAIL(--email)"
    fi
    
    if [ -n "$missing" ]; then
        log_error "缺少必要配置:$missing"
        echo ""
        echo "请通过命令行参数提供:"
        echo "  ./server-deploy.sh --domain=api.example.com --email=admin@example.com --cf-token=xxx"
        exit 1
    fi
    
    log_success "配置验证通过"
    log_info "域名: $SERVER_DOMAIN"
    log_info "邮箱: $SERVER_EMAIL"
    log_info "前端项目: $CF_PROJECT_NAME"
}

#===============================================================================
# 阶段0: 下载并解压部署包
#===============================================================================

download_and_extract() {
    if [ -z "$PACKAGE_URL" ]; then
        if [ -d "$SCRIPT_DIR/backend" ] && [ -d "$SCRIPT_DIR/frontend" ]; then
            log_info "使用当前目录的部署文件"
            return 0
        else
            log_warn "未指定部署包URL，且当前目录没有部署文件"
            return 0
        fi
    fi
    
    log_step "阶段0: 下载并解压部署包"
    
    local package_file="$SCRIPT_DIR/deploy-package.tar.gz"
    
    log_info "下载部署包: $PACKAGE_URL"
    if curl -fSL "$PACKAGE_URL" -o "$package_file"; then
        log_success "下载完成"
    else
        log_error "下载失败"
        exit 1
    fi
    
    log_info "解压部署包..."
    if tar -xzf "$package_file" -C "$SCRIPT_DIR"; then
        log_success "解压完成"
    else
        log_error "解压失败"
        exit 1
    fi
}

#===============================================================================
# 阶段1: Docker 环境准备
#===============================================================================

install_docker() {
    log_info "安装 Docker..."
    curl -fsSL https://get.docker.com | sh
    systemctl start docker
    systemctl enable docker
    log_success "Docker 安装完成"
}

check_docker() {
    log_step "阶段1: 检查 Docker 环境"
    
    if [ "$SKIP_DOCKER" = "true" ]; then
        log_info "跳过 Docker 检查"
        return 0
    fi
    
    if command -v docker &> /dev/null; then
        local docker_version=$(docker --version 2>/dev/null | awk '{print $3}' | tr -d ',')
        log_success "Docker 已安装: $docker_version"
        
        if docker info &> /dev/null; then
            log_success "Docker 服务运行中"
        else
            log_warn "Docker 服务未运行，正在启动..."
            systemctl start docker || true
        fi
    else
        log_warn "Docker 未安装"
        install_docker
    fi
    
    # 检查 Docker Compose
    if docker compose version &> /dev/null; then
        log_success "Docker Compose (插件版) 已安装"
        COMPOSE_CMD="docker compose"
    elif command -v docker-compose &> /dev/null; then
        log_success "Docker Compose (独立版) 已安装"
        COMPOSE_CMD="docker-compose"
    else
        log_warn "Docker Compose 未安装，正在安装..."
        apt-get update && apt-get install -y docker-compose-plugin 2>/dev/null || \
        yum install -y docker-compose-plugin 2>/dev/null
        COMPOSE_CMD="docker compose"
    fi
}

#===============================================================================
# 阶段2: 部署后端
#===============================================================================

deploy_backend() {
    log_step "阶段2: 部署后端服务"
    
    local backend_dir="$SCRIPT_DIR/backend"
    
    if [ ! -d "$backend_dir" ]; then
        log_error "后端目录不存在: $backend_dir"
        exit 1
    fi
    
    cd "$backend_dir"
    
    chmod +x cherry wait-for-it.sh 2>/dev/null || true
    
    log_info "停止旧服务..."
    $COMPOSE_CMD down 2>/dev/null || true
    
    log_info "启动新服务..."
    if $COMPOSE_CMD up -d --build; then
        log_success "后端服务启动成功"
    else
        log_error "后端服务启动失败"
        $COMPOSE_CMD logs --tail=50
        exit 1
    fi
    
    log_info "等待服务就绪..."
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -s http://localhost:8080/health 2>/dev/null | grep -q "ok\|healthy\|status"; then
            log_success "后端服务已就绪"
            return 0
        fi
        echo -n "."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    echo ""
    log_warn "服务启动超时，请检查日志: docker logs web"
}

#===============================================================================
# 阶段3: 部署 Cloudflare Pages
#===============================================================================

install_node() {
    log_info "检查 Node.js..."
    
    if command -v node &> /dev/null; then
        local node_version=$(node --version 2>/dev/null)
        log_success "Node.js 已安装: $node_version"
        return 0
    fi
    
    log_info "安装 Node.js..."
    
    if command -v apt-get &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
        apt-get install -y nodejs
    elif command -v yum &> /dev/null; then
        curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
        yum install -y nodejs
    else
        log_error "无法安装 Node.js，请手动安装"
        return 1
    fi
    
    log_success "Node.js 安装完成"
}

deploy_cloudflare_pages() {
    if [ "$SKIP_FRONTEND" = "true" ]; then
        log_info "跳过 Cloudflare Pages 部署"
        DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
        return 0
    fi
    
    log_step "阶段3: 部署 Cloudflare Pages"
    
    local frontend_dir="$SCRIPT_DIR/frontend/admin-frontend"
    
    if [ ! -d "$frontend_dir" ]; then
        log_warn "前端目录不存在: $frontend_dir"
        DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
        return 0
    fi
    
    install_node || return 1
    
    log_info "安装 wrangler..."
    npm install -g wrangler 2>&1 || {
        log_error "wrangler 安装失败"
        return 1
    }
    
    if [ -n "$CLOUDFLARE_API_TOKEN" ]; then
        log_success "使用 API Token 认证 Cloudflare"
        export CLOUDFLARE_API_TOKEN="$CLOUDFLARE_API_TOKEN"
    else
        log_warn "未提供 Cloudflare API Token"
        echo ""
        read -p "请输入 Cloudflare API Token: " input_token
        if [ -z "$input_token" ]; then
            log_error "未提供 API Token，跳过前端部署"
            DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
            return 1
        fi
        export CLOUDFLARE_API_TOKEN="$input_token"
    fi
    
    log_info "验证 Cloudflare 认证..."
    if ! wrangler whoami 2>&1 | grep -qi "account"; then
        log_error "Cloudflare 认证失败"
        DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
        return 1
    fi
    log_success "Cloudflare 认证成功"
    
    log_info "部署 admin-frontend..."
    
    # 创建项目（如果不存在）
    wrangler pages project create "$CF_PROJECT_NAME" --production-branch=main 2>/dev/null || true
    
    # 部署
    local deploy_output
    deploy_output=$(wrangler pages deploy "$frontend_dir" --project-name="$CF_PROJECT_NAME" --commit-dirty=true --branch=main 2>&1)
    local deploy_status=$?
    
    if [ $deploy_status -eq 0 ]; then
        # 提取URL
        local clean_output=$(echo "$deploy_output" | sed 's/\x1b\[[0-9;]*m//g' | tr -d '\r')
        DEPLOYED_URL=$(echo "$clean_output" | grep -oE 'https://[a-zA-Z0-9.-]+\.pages\.dev' | head -1)
        
        if [ -z "$DEPLOYED_URL" ]; then
            DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
        fi
        
        log_success "前端部署成功: $DEPLOYED_URL"
    else
        log_error "前端部署失败"
        echo "$deploy_output"
        DEPLOYED_URL="https://${CF_PROJECT_NAME}.pages.dev"
        return 1
    fi
    
    cd "$SCRIPT_DIR"
}

#===============================================================================
# 阶段4: 申请 SSL 证书（调用本地API）
#===============================================================================

apply_ssl() {
    if [ "$SKIP_SSL" = "true" ]; then
        log_info "跳过 SSL 申请"
        return 0
    fi
    
    log_step "阶段4: 申请 SSL 证书"
    
    # 预检查
    log_info "检查域名解析..."
    local RESOLVED_IP=$(dig +short $SERVER_DOMAIN 2>/dev/null | head -1)
    local SERVER_IP=$(curl -s --connect-timeout 5 ifconfig.me 2>/dev/null || curl -s --connect-timeout 5 icanhazip.com 2>/dev/null)
    log_info "域名 $SERVER_DOMAIN 解析到: $RESOLVED_IP"
    log_info "服务器公网IP: $SERVER_IP"
    
    if [ "$RESOLVED_IP" != "$SERVER_IP" ] && [ -n "$RESOLVED_IP" ] && [ -n "$SERVER_IP" ]; then
        log_warn "域名解析IP与服务器IP不匹配！"
    fi
    
    # 构建请求数据
    local allowed_origins="[\"$DEPLOYED_URL\"]"
    local ssl_data="{\"email\":\"$SERVER_EMAIL\",\"domains\":[\"$SERVER_DOMAIN\"],\"allowed_origins\":$allowed_origins}"
    
    log_info "申请 SSL 证书: $SERVER_DOMAIN"
    log_info "允许的 Origins: $allowed_origins"
    log_info "调用本地API: POST http://localhost:8080/api/local/ssl/apply"
    
    local ssl_response
    ssl_response=$(curl -s -X POST http://localhost:8080/api/local/ssl/apply \
        -H 'Content-Type: application/json' \
        -d "$ssl_data" 2>&1)
    
    echo ""
    log_info "API响应:"
    echo "$ssl_response" | head -50
    echo ""
    
    if echo "$ssl_response" | grep -q '"success"[[:space:]]*:[[:space:]]*true\|证书申请成功'; then
        log_success "SSL 证书申请成功"
        log_success "CORS 已配置为允许: $DEPLOYED_URL"
    else
        log_warn "SSL 证书申请可能失败"
        log_info "请确保:"
        log_info "  1. 域名 $SERVER_DOMAIN 已解析到此服务器"
        log_info "  2. 80 端口可以从外部访问"
        log_info "  3. 可以稍后手动申请"
    fi
}

#===============================================================================
# 阶段5: 配置 Cloudflare WAF 规则（禁止中国大陆访问）
#===============================================================================

configure_waf() {
    log_step "阶段5: 配置 Cloudflare WAF 规则"
    
    if [ -z "$CLOUDFLARE_API_TOKEN" ]; then
        log_warn "未提供 Cloudflare API Token，跳过 WAF 配置"
        return 0
    fi
    
    log_info "配置地区访问限制（禁止中国大陆访问）..."
    
    # 获取账户ID
    local account_info
    account_info=$(curl -s -X GET "https://api.cloudflare.com/client/v4/accounts" \
        -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
        -H "Content-Type: application/json" 2>&1)
    
    local account_id
    account_id=$(echo "$account_info" | grep -oE '"id":"[a-f0-9]{32}"' | head -1 | sed 's/"id":"//;s/"//')
    
    if [ -z "$account_id" ]; then
        log_warn "无法获取 Cloudflare 账户ID，跳过 WAF 配置"
        log_info "请手动在 Cloudflare Dashboard 配置 WAF 规则"
        return 0
    fi
    
    log_info "账户ID: ${account_id:0:8}..."
    
    # 规则表达式：禁止中国大陆访问前端项目
    local rule_expression="(ip.geoip.country eq \"CN\" and http.host contains \"${CF_PROJECT_NAME}\")"
    local rule_description="Block-China-${CF_PROJECT_NAME}"
    
    # 获取现有规则集
    local rulesets_response
    rulesets_response=$(curl -s -X GET "https://api.cloudflare.com/client/v4/accounts/${account_id}/rulesets" \
        -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
        -H "Content-Type: application/json" 2>&1)
    
    # 查找 http_request_firewall_custom 规则集
    local ruleset_id
    ruleset_id=$(echo "$rulesets_response" | grep -oE '"id":"[a-f0-9-]+"[^}]*"phase":"http_request_firewall_custom"' | head -1 | grep -oE '"id":"[a-f0-9-]+"' | sed 's/"id":"//;s/"//')
    
    if [ -n "$ruleset_id" ]; then
        log_info "找到现有规则集: ${ruleset_id:0:8}..."
        
        # 获取现有规则
        local ruleset_detail
        ruleset_detail=$(curl -s -X GET "https://api.cloudflare.com/client/v4/accounts/${account_id}/rulesets/${ruleset_id}" \
            -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
            -H "Content-Type: application/json" 2>&1)
        
        # 检查规则是否已存在
        if echo "$ruleset_detail" | grep -q "$rule_description"; then
            log_success "WAF 规则已存在: $rule_description"
            return 0
        fi
        
        # 添加新规则到现有规则集
        local add_rule_payload="{\"rules\":[{\"action\":\"block\",\"expression\":\"$rule_expression\",\"description\":\"$rule_description\",\"enabled\":true}]}"
        
        local add_response
        add_response=$(curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/${account_id}/rulesets/${ruleset_id}/rules" \
            -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
            -H "Content-Type: application/json" \
            -d "$add_rule_payload" 2>&1)
        
        if echo "$add_response" | grep -q '"success":true'; then
            log_success "WAF 规则添加成功: $rule_description"
        else
            log_warn "WAF 规则添加失败"
            log_info "请手动在 Cloudflare Dashboard 配置"
        fi
    else
        log_info "创建新规则集..."
        
        # 创建新规则集
        local create_payload="{\"name\":\"GeoBlock Rules\",\"kind\":\"root\",\"phase\":\"http_request_firewall_custom\",\"rules\":[{\"action\":\"block\",\"expression\":\"$rule_expression\",\"description\":\"$rule_description\",\"enabled\":true}]}"
        
        local create_response
        create_response=$(curl -s -X POST "https://api.cloudflare.com/client/v4/accounts/${account_id}/rulesets" \
            -H "Authorization: Bearer $CLOUDFLARE_API_TOKEN" \
            -H "Content-Type: application/json" \
            -d "$create_payload" 2>&1)
        
        if echo "$create_response" | grep -q '"success":true'; then
            log_success "WAF 规则集创建成功: $rule_description"
        else
            log_warn "WAF 规则集创建失败"
            log_info "请手动在 Cloudflare Dashboard 配置"
            log_info "规则表达式: $rule_expression"
        fi
    fi
}

#===============================================================================
# 阶段6: 验证部署
#===============================================================================

verify_deployment() {
    log_step "阶段6: 验证部署"
    
    local all_ok=true
    
    log_info "验证后端服务 (HTTP)..."
    if curl -s http://localhost:8080/health 2>/dev/null | grep -q "ok\|healthy\|status"; then
        log_success "后端服务 (HTTP): 正常"
    else
        log_error "后端服务 (HTTP): 异常"
        all_ok=false
    fi
    
    if [ "$SKIP_SSL" != "true" ]; then
        log_info "验证 HTTPS..."
        sleep 2
        if curl -sk "https://$SERVER_DOMAIN/health" 2>/dev/null | grep -q "ok\|healthy\|status"; then
            log_success "HTTPS: 正常"
        else
            log_warn "HTTPS: 可能还在生效中，请稍后验证"
        fi
    fi
    
    log_info "Docker 服务状态:"
    docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' 2>/dev/null || true
    
    if [ "$all_ok" = true ]; then
        log_success "部署验证通过"
    fi
}

#===============================================================================
# 清理
#===============================================================================

cleanup() {
    log_info "清理部署文件..."
    
    # 清理下载的压缩包
    rm -f "$SCRIPT_DIR/deploy-package.tar.gz" 2>/dev/null || true
    
    # 清理前端目录（已部署到Cloudflare）
    rm -rf "$SCRIPT_DIR/frontend" 2>/dev/null || true
    
    # 清理配置文件
    rm -f "$SCRIPT_DIR/deploy-config.json" 2>/dev/null || true
    
    # 清理backend中不再需要的构建文件（镜像已构建完成）
    local backend_dir="$SCRIPT_DIR/backend"
    if [ -d "$backend_dir" ]; then
        rm -f "$backend_dir/cherry" 2>/dev/null || true
        rm -f "$backend_dir/Dockerfile" 2>/dev/null || true
        rm -f "$backend_dir/wait-for-it.sh" 2>/dev/null || true
        rm -rf "$backend_dir/config" 2>/dev/null || true
        
        # 完全清理（包括docker-compose.yml和整个backend目录）
        rm -f "$backend_dir/docker-compose.yml" 2>/dev/null || true
        rmdir "$backend_dir" 2>/dev/null || true
        
        log_success "已完全清理所有部署文件"
    fi
    
    # 最后删除部署脚本自身
    rm -f "$SCRIPT_DIR/server-deploy.sh" 2>/dev/null || true
    
    log_success "清理完成"
    log_info "容器管理命令: docker restart web | docker logs -f web | docker stop web"
}

#===============================================================================
# 主流程
#===============================================================================

main() {
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║              服务器端一键部署脚本                             ║"
    echo "║     Docker部署 → Cloudflare Pages → SSL证书                   ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    parse_args "$@"
    load_deploy_config
    validate_config
    
    echo ""
    log_info "部署配置:"
    echo "  域名: $SERVER_DOMAIN"
    echo "  邮箱: $SERVER_EMAIL"
    echo "  前端项目: $CF_PROJECT_NAME"
    if [ -n "$CLOUDFLARE_API_TOKEN" ]; then
        echo "  CF Token: ${CLOUDFLARE_API_TOKEN:0:10}...（已提供）"
    fi
    echo ""
    echo "部署流程:"
    echo "  阶段1: 检查/安装 Docker"
    echo "  阶段2: 部署后端服务 (Docker Compose)"
    echo "  阶段3: 部署 Cloudflare Pages"
    echo "  阶段4: 申请 SSL 证书 (使用本地API)"
    echo "  阶段5: 配置 WAF 规则 (禁止中国大陆访问)"
    echo "  阶段6: 验证部署"
    echo ""
    
    if [ "$AUTO_YES" != "true" ]; then
        read -p "确认开始部署? [Y/n] " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]?$ ]]; then
            log_info "已取消"
            exit 0
        fi
    fi
    
    START_TIME=$(date +%s)
    
    download_and_extract
    check_docker
    deploy_backend
    deploy_cloudflare_pages
    apply_ssl
    configure_waf
    verify_deployment
    cleanup
    
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    MINUTES=$((DURATION / 60))
    SECONDS=$((DURATION % 60))
    
    echo ""
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                      部署完成!                                ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo -e "${RED}后端 API 地址：${NC}"
    echo -e "  ${GREEN}https://$SERVER_DOMAIN${NC}"
    echo ""
    echo -e "${RED}管理后台地址：${NC}"
    echo -e "  ${GREEN}$DEPLOYED_URL${NC}"
    echo ""
    echo -e "${YELLOW}------------------------部署已全部就绪---------------------------------${NC}"
    echo ""
    echo "  总耗时: ${MINUTES}分${SECONDS}秒"
    echo ""
    echo "  查看日志: docker logs -f web"
}

main "$@"
