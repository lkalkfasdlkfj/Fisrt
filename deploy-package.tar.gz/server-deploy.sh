#!/bin/bash
#===============================================================================
# 服务器端一键部署脚本
# 
# 功能：
#   1. 下载并解压部署包（如果指定了URL）
#   2. 安装 Docker（如果需要）
#   3. 部署后端服务（Docker Compose）
#   4. 申请 SSL 证书（自动配置 CORS）
#   5. 部署前端到 Cloudflare Pages
#
# 使用方式1（推荐 - 一行命令完成所有操作）：
#   curl -fsSL https://raw.githubusercontent.com/xxx/server-deploy.sh | bash -s -- \
#     --url=https://github.com/xxx/releases/download/v1.0/deploy-package.tar.gz \
#     --domain=api.example.com --email=admin@example.com
#
# 使用方式2（先下载脚本再执行）：
#   curl -L <脚本链接> -o server-deploy.sh
#   chmod +x server-deploy.sh
#   ./server-deploy.sh --url=<部署包链接> --domain=api.example.com --email=admin@example.com
#
# 使用方式3（已解压部署包后执行）：
#   ./server-deploy.sh --domain=api.example.com --email=admin@example.com
#===============================================================================

set -e

# 颜色定义
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
BLUE='\033[0;34m'
CYAN='\033[0;36m'
NC='\033[0m'

# 脚本所在目录
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# 默认配置
SERVER_DOMAIN=""
SERVER_EMAIL=""
PACKAGE_URL=""
SKIP_DOCKER="false"
SKIP_SSL="false"
SKIP_FRONTEND="false"
AUTO_YES="false"

# Cloudflare Pages 固定项目名
CF_PROJECT_UTOLUCK="utoluck"
CF_PROJECT_COINTOUSDT="cointousdt"
CF_PROJECT_ADMIN="backend-admin"

# 部署后的真实URL（部署时更新）
DEPLOYED_URL_UTOLUCK=""
DEPLOYED_URL_COINTOUSDT=""
DEPLOYED_URL_ADMIN=""

# Docker Compose 命令
COMPOSE_CMD=""

#===============================================================================
# 工具函数
#===============================================================================

log_info() {
    echo -e "${CYAN}[INFO]${NC} $1"
}

log_success() {
    echo -e "${GREEN}[✓]${NC} $1"
}

log_warn() {
    echo -e "${YELLOW}[⚠]${NC} $1"
}

log_error() {
    echo -e "${RED}[✗]${NC} $1"
}

log_step() {
    echo -e "\n${BLUE}========================================${NC}"
    echo -e "${BLUE}  $1${NC}"
    echo -e "${BLUE}========================================${NC}"
}

show_help() {
    cat << EOF
服务器端一键部署脚本

使用方式:
    ./server-deploy.sh [选项]

选项:
    --url=URL           部署包下载链接（GitHub Release等）
    --domain=DOMAIN     服务器域名（用于SSL证书）
    --email=EMAIL       SSL证书邮箱
    --skip-docker       跳过Docker安装检查
    --skip-ssl          跳过SSL证书申请
    --skip-frontend     跳过Cloudflare Pages部署
    --yes, -y           自动确认，跳过交互提示
    --help              显示帮助信息

示例:
    # 一行命令完成部署（推荐）
    ./server-deploy.sh --url=https://github.com/xxx/releases/download/v1.0/deploy-package.tar.gz \\
        --domain=api.example.com --email=admin@example.com

    # 已解压部署包后执行
    ./server-deploy.sh --domain=api.example.com --email=admin@example.com
EOF
    exit 0
}

parse_args() {
    while [[ $# -gt 0 ]]; do
        case $1 in
            --url=*)
                PACKAGE_URL="${1#*=}"
                ;;
            --domain=*)
                SERVER_DOMAIN="${1#*=}"
                ;;
            --email=*)
                SERVER_EMAIL="${1#*=}"
                ;;
            --skip-docker)
                SKIP_DOCKER="true"
                ;;
            --skip-ssl)
                SKIP_SSL="true"
                ;;
            --skip-frontend)
                SKIP_FRONTEND="true"
                ;;
            --yes|-y)
                AUTO_YES="true"
                ;;
            --help|-h)
                show_help
                ;;
            *)
                log_error "未知参数: $1"
                show_help
                ;;
        esac
        shift
    done
}

# 从 deploy-config.json 读取配置
load_deploy_config() {
    local config_file="$SCRIPT_DIR/deploy-config.json"
    
    if [ -f "$config_file" ]; then
        log_info "从 deploy-config.json 读取配置..."
        
        # 使用 grep 和 sed 解析 JSON（避免依赖 jq）
        if [ -z "$SERVER_DOMAIN" ]; then
            SERVER_DOMAIN=$(grep -o '"server_domain"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
        fi
        if [ -z "$SERVER_EMAIL" ]; then
            SERVER_EMAIL=$(grep -o '"server_email"[[:space:]]*:[[:space:]]*"[^"]*"' "$config_file" | sed 's/.*: *"\([^"]*\)".*/\1/')
        fi
    fi
}

validate_config() {
    local missing=""
    
    [ -z "$SERVER_DOMAIN" ] && missing="$missing SERVER_DOMAIN(--domain)"
    [ -z "$SERVER_EMAIL" ] && missing="$missing SERVER_EMAIL(--email)"
    
    if [ -n "$missing" ]; then
        log_error "缺少必要配置:$missing"
        echo ""
        echo "请通过命令行参数提供:"
        echo "  ./server-deploy.sh --url=<部署包链接> --domain=api.example.com --email=admin@example.com"
        exit 1
    fi
    
    log_success "配置验证通过"
    log_info "域名: $SERVER_DOMAIN"
    log_info "邮箱: $SERVER_EMAIL"
    [ -n "$PACKAGE_URL" ] && log_info "部署包: $PACKAGE_URL"
}

#===============================================================================
# 阶段0: 下载并解压部署包
#===============================================================================

download_and_extract() {
    if [ -z "$PACKAGE_URL" ]; then
        # 没有指定URL，检查当前目录是否已有部署文件
        if [ -d "$SCRIPT_DIR/backend" ] && [ -d "$SCRIPT_DIR/frontend" ]; then
            log_info "使用当前目录的部署文件"
            return 0
        else
            log_warn "未指定部署包URL，且当前目录没有部署文件"
            log_info "请使用 --url 参数指定部署包下载链接"
            return 0
        fi
    fi
    
    log_step "阶段0: 下载并解压部署包"
    
    local package_file="$SCRIPT_DIR/deploy-package.tar.gz"
    
    # 下载部署包
    log_info "下载部署包: $PACKAGE_URL"
    if curl -fSL "$PACKAGE_URL" -o "$package_file"; then
        log_success "下载完成"
    else
        log_error "下载失败，请检查URL是否正确"
        exit 1
    fi
    
    # 解压
    log_info "解压部署包..."
    if tar -xzf "$package_file" -C "$SCRIPT_DIR"; then
        log_success "解压完成"
    else
        log_error "解压失败"
        exit 1
    fi
    
    # 验证解压结果
    if [ -d "$SCRIPT_DIR/backend" ]; then
        log_success "后端目录已就绪"
    else
        log_error "解压后未找到 backend 目录"
        exit 1
    fi
    
    if [ -d "$SCRIPT_DIR/frontend" ]; then
        log_success "前端目录已就绪"
    else
        log_warn "未找到 frontend 目录，将跳过前端部署"
        SKIP_FRONTEND="true"
    fi
}

#===============================================================================
# 阶段1: Docker 环境准备
#===============================================================================

repair_docker_daemon_json() {
    log_info "修复 Docker daemon.json..."
    mkdir -p /etc/docker
    cat > /etc/docker/daemon.json << 'EOF'
{
  "registry-mirrors": [
    "https://docker.mirrors.ustc.edu.cn",
    "https://hub-mirror.c.163.com",
    "https://mirror.baidubce.com"
  ],
  "log-driver": "json-file",
  "log-opts": {
    "max-size": "100m",
    "max-file": "3"
  }
}
EOF
    systemctl daemon-reload
    systemctl restart docker || true
}

install_docker() {
    log_info "安装 Docker..."
    
    # 使用官方脚本安装
    curl -fsSL https://get.docker.com | sh
    
    # 启动 Docker
    systemctl start docker
    systemctl enable docker
    
    # 配置镜像加速
    repair_docker_daemon_json
    
    log_success "Docker 安装完成"
}

check_docker() {
    log_step "阶段1: 检查 Docker 环境"
    
    if [ "$SKIP_DOCKER" = "true" ]; then
        log_info "跳过 Docker 检查"
        return 0
    fi
    
    # 检查 Docker
    if command -v docker &> /dev/null; then
        local docker_version=$(docker --version 2>/dev/null | awk '{print $3}' | tr -d ',')
        log_success "Docker 已安装: $docker_version"
        
        # 检查 Docker 是否运行
        if docker info &> /dev/null; then
            log_success "Docker 服务运行中"
        else
            log_warn "Docker 服务未运行，正在启动..."
            systemctl start docker || true
            
            if ! docker info &> /dev/null; then
                # 尝试修复
                repair_docker_daemon_json
                if ! docker info &> /dev/null; then
                    log_error "Docker 服务启动失败"
                    exit 1
                fi
            fi
            log_success "Docker 服务已启动"
        fi
    else
        log_warn "Docker 未安装"
        install_docker
    fi
    
    # 检查 Docker Compose
    if docker compose version &> /dev/null; then
        log_success "Docker Compose (插件版) 已安装"
        COMPOSE_CMD="docker compose"
    elif command -v docker-compose &> /dev/null; then
        log_success "Docker Compose (独立版) 已安装"
        COMPOSE_CMD="docker-compose"
    else
        log_warn "Docker Compose 未安装，正在安装..."
        apt-get update && apt-get install -y docker-compose-plugin 2>/dev/null || \
        yum install -y docker-compose-plugin 2>/dev/null || {
            log_error "Docker Compose 安装失败"
            exit 1
        }
        
        if docker compose version &> /dev/null; then
            COMPOSE_CMD="docker compose"
        else
            log_error "Docker Compose 安装后仍不可用"
            exit 1
        fi
    fi
}

#===============================================================================
# 阶段2: 部署后端
#===============================================================================

deploy_backend() {
    log_step "阶段2: 部署后端服务"
    
    local backend_dir="$SCRIPT_DIR/backend"
    
    if [ ! -d "$backend_dir" ]; then
        log_error "后端目录不存在: $backend_dir"
        exit 1
    fi
    
    cd "$backend_dir"
    
    # 设置执行权限
    chmod +x cherry wait-for-it.sh 2>/dev/null || true
    
    # 停止旧服务
    log_info "停止旧服务..."
    $COMPOSE_CMD down 2>/dev/null || true
    
    # 启动新服务
    log_info "启动新服务..."
    if $COMPOSE_CMD up -d --build; then
        log_success "后端服务启动成功"
    else
        log_error "后端服务启动失败"
        $COMPOSE_CMD logs --tail=50
        exit 1
    fi
    
    # 等待服务就绪
    log_info "等待服务就绪..."
    local max_attempts=30
    local attempt=1
    
    while [ $attempt -le $max_attempts ]; do
        if curl -s http://localhost:8080/health 2>/dev/null | grep -q "ok\|healthy\|status"; then
            log_success "后端服务已就绪"
            return 0
        fi
        echo -n "."
        sleep 2
        attempt=$((attempt + 1))
    done
    
    echo ""
    log_warn "服务启动超时，请检查日志: docker logs web"
}

#===============================================================================
# 阶段3: 申请 SSL 证书
#===============================================================================

apply_ssl() {
    if [ "$SKIP_SSL" = "true" ]; then
        log_info "跳过 SSL 申请"
        return 0
    fi
    
    log_step "阶段3: 申请 SSL 证书"
    
    # 构建允许的 Origins 列表
    local allowed_origins="[\"https://${CF_PROJECT_UTOLUCK}.pages.dev\",\"https://${CF_PROJECT_COINTOUSDT}.pages.dev\",\"https://${CF_PROJECT_ADMIN}.pages.dev\"]"
    
    log_info "申请 SSL 证书: $SERVER_DOMAIN"
    log_info "允许的 Origins: $allowed_origins"
    
    # 调用后端 API 申请 SSL
    local ssl_data="{\"email\":\"$SERVER_EMAIL\",\"domains\":[\"$SERVER_DOMAIN\"],\"allowed_origins\":$allowed_origins}"
    
    log_info "请求数据: $ssl_data"
    
    local ssl_response
    ssl_response=$(curl -s -X POST http://localhost:8080/api/admin/ssl/apply \
        -H 'Content-Type: application/json' \
        -d "$ssl_data" 2>/dev/null)
    
    log_info "响应: $ssl_response"
    
    if echo "$ssl_response" | grep -q '"success"[[:space:]]*:[[:space:]]*true\|证书申请成功'; then
        log_success "SSL 证书申请成功"
        log_success "CORS 已自动配置为允许 Cloudflare Pages 域名"
    else
        log_warn "SSL 证书申请可能失败"
        log_warn "响应: $ssl_response"
        echo ""
        log_info "请确保:"
        log_info "  1. 域名 $SERVER_DOMAIN 已解析到此服务器"
        log_info "  2. 80 端口可以从外部访问"
        log_info "  3. 可以稍后手动申请: curl -X POST http://localhost:8080/api/admin/ssl/apply ..."
    fi
}

# 使用真实部署URL更新CORS配置
update_cors_with_real_urls() {
    # 如果跳过了SSL，则不更新
    if [ "$SKIP_SSL" = "true" ]; then
        return 0
    fi
    
    # 检查是否有真实URL需要更新
    if [ -z "$DEPLOYED_URL_UTOLUCK" ] && [ -z "$DEPLOYED_URL_COINTOUSDT" ] && [ -z "$DEPLOYED_URL_ADMIN" ]; then
        log_info "没有新的URL需要更新CORS配置"
        return 0
    fi
    
    log_info "使用真实部署URL更新CORS配置..."
    
    # 构建真实的 Origins 列表（使用数组避免逗号问题）
    local origins=()
    [ -n "$DEPLOYED_URL_UTOLUCK" ] && origins+=("\"$DEPLOYED_URL_UTOLUCK\"")
    [ -n "$DEPLOYED_URL_COINTOUSDT" ] && origins+=("\"$DEPLOYED_URL_COINTOUSDT\"")
    [ -n "$DEPLOYED_URL_ADMIN" ] && origins+=("\"$DEPLOYED_URL_ADMIN\"")
    
    # 用逗号连接数组元素
    local IFS=','
    local origins_array="${origins[*]}"
    
    local update_data="{\"domain\":\"$SERVER_DOMAIN\",\"allowed_origins\":[$origins_array]}"
    
    log_info "更新CORS配置: $update_data"
    
    local update_response
    update_response=$(curl -s -X POST http://localhost:8080/api/admin/ssl/proxy \
        -H 'Content-Type: application/json' \
        -d "$update_data" 2>/dev/null)
    
    if echo "$update_response" | grep -qi "success\|ok"; then
        log_success "CORS配置已更新为真实部署URL"
    else
        log_warn "CORS配置更新可能失败: $update_response"
        log_info "您可以稍后手动更新CORS配置"
    fi
}

#===============================================================================
# 阶段4: 部署 Cloudflare Pages
#===============================================================================

install_node() {
    log_info "检查 Node.js..."
    
    if command -v node &> /dev/null; then
        local node_version=$(node --version 2>/dev/null)
        log_success "Node.js 已安装: $node_version"
        return 0
    fi
    
    log_info "安装 Node.js..."
    
    # 尝试使用 NodeSource
    if command -v apt-get &> /dev/null; then
        curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
        apt-get install -y nodejs
    elif command -v yum &> /dev/null; then
        curl -fsSL https://rpm.nodesource.com/setup_20.x | bash -
        yum install -y nodejs
    else
        log_error "无法安装 Node.js，请手动安装"
        return 1
    fi
    
    if command -v node &> /dev/null; then
        log_success "Node.js 安装完成"
    else
        log_error "Node.js 安装失败"
        return 1
    fi
}

deploy_cloudflare_pages() {
    if [ "$SKIP_FRONTEND" = "true" ]; then
        log_info "跳过 Cloudflare Pages 部署"
        return 0
    fi
    
    log_step "阶段4: 部署 Cloudflare Pages"
    
    local frontend_dir="$SCRIPT_DIR/frontend"
    
    if [ ! -d "$frontend_dir" ]; then
        log_warn "前端目录不存在: $frontend_dir"
        log_info "跳过 Cloudflare Pages 部署"
        return 0
    fi
    
    # 安装 Node.js
    install_node || return 1
    
    # 安装 wrangler
    log_info "安装 wrangler..."
    npm install -g wrangler 2>&1 || {
        log_error "wrangler 安装失败"
        return 1
    }
    
    # 检查登录状态
    log_info "检查 Cloudflare 登录状态..."
    local wrangler_status
    wrangler_status=$(wrangler whoami 2>&1 || true)
    
    if echo "$wrangler_status" | grep -qi "not logged in\|error\|You are not"; then
        log_warn "需要登录 Cloudflare"
        echo ""
        echo -e "${YELLOW}========================================${NC}"
        echo -e "${YELLOW}  请完成 Cloudflare 授权登录${NC}"
        echo -e "${YELLOW}========================================${NC}"
        echo ""
        echo "执行 wrangler login 后，会显示一个链接"
        echo "请复制该链接到浏览器中打开并完成授权"
        echo ""
        
        # 执行 wrangler login
        wrangler login || {
            log_error "Cloudflare 登录失败"
            return 1
        }
        
        log_success "Cloudflare 登录成功"
    else
        log_success "Cloudflare 已登录"
    fi
    
    # 部署各前端项目并捕获真实URL
    log_info "开始部署前端项目..."
    
    # 部署 uToLuck
    if [ -d "$frontend_dir/uToLuck" ]; then
        log_info "部署 uToLuck..."
        cd "$frontend_dir/uToLuck"
        local deploy_output
        deploy_output=$(wrangler pages deploy . --project-name="$CF_PROJECT_UTOLUCK" --commit-dirty=true 2>&1) || log_warn "uToLuck 部署失败"
        echo "$deploy_output"
        # 从输出中提取真实URL
        DEPLOYED_URL_UTOLUCK=$(echo "$deploy_output" | grep -oE 'https://[a-zA-Z0-9.-]+\.pages\.dev' | tail -1)
        if [ -z "$DEPLOYED_URL_UTOLUCK" ]; then
            DEPLOYED_URL_UTOLUCK="https://${CF_PROJECT_UTOLUCK}.pages.dev"
        fi
        log_success "uToLuck 部署完成: $DEPLOYED_URL_UTOLUCK"
    fi
    
    # 部署 CoinToUsdt
    if [ -d "$frontend_dir/CoinToUsdt" ]; then
        log_info "部署 CoinToUsdt..."
        cd "$frontend_dir/CoinToUsdt"
        deploy_output=$(wrangler pages deploy . --project-name="$CF_PROJECT_COINTOUSDT" --commit-dirty=true 2>&1) || log_warn "CoinToUsdt 部署失败"
        echo "$deploy_output"
        DEPLOYED_URL_COINTOUSDT=$(echo "$deploy_output" | grep -oE 'https://[a-zA-Z0-9.-]+\.pages\.dev' | tail -1)
        if [ -z "$DEPLOYED_URL_COINTOUSDT" ]; then
            DEPLOYED_URL_COINTOUSDT="https://${CF_PROJECT_COINTOUSDT}.pages.dev"
        fi
        log_success "CoinToUsdt 部署完成: $DEPLOYED_URL_COINTOUSDT"
    fi
    
    # 部署 backendAdmin
    if [ -d "$frontend_dir/backendAdmin" ]; then
        log_info "部署 backendAdmin..."
        cd "$frontend_dir/backendAdmin"
        deploy_output=$(wrangler pages deploy . --project-name="$CF_PROJECT_ADMIN" --commit-dirty=true 2>&1) || log_warn "backendAdmin 部署失败"
        echo "$deploy_output"
        DEPLOYED_URL_ADMIN=$(echo "$deploy_output" | grep -oE 'https://[a-zA-Z0-9.-]+\.pages\.dev' | tail -1)
        if [ -z "$DEPLOYED_URL_ADMIN" ]; then
            DEPLOYED_URL_ADMIN="https://${CF_PROJECT_ADMIN}.pages.dev"
        fi
        log_success "backendAdmin 部署完成: $DEPLOYED_URL_ADMIN"
    fi
    
    cd "$SCRIPT_DIR"
    
    # 显示所有部署的URL
    echo ""
    log_success "所有前端项目部署完成"
    echo ""
    echo -e "${GREEN}部署的真实URL:${NC}"
    echo "  uToLuck:      $DEPLOYED_URL_UTOLUCK"
    echo "  CoinToUsdt:   $DEPLOYED_URL_COINTOUSDT"
    echo "  backendAdmin: $DEPLOYED_URL_ADMIN"
    echo ""
    
    # 更新SSL证书的CORS配置（使用真实URL）
    update_cors_with_real_urls
}

#===============================================================================
# 阶段5: 验证部署
#===============================================================================

verify_deployment() {
    log_step "阶段5: 验证部署"
    
    local all_ok=true
    
    # 验证后端 HTTP
    log_info "验证后端服务 (HTTP)..."
    if curl -s http://localhost:8080/health 2>/dev/null | grep -q "ok\|healthy\|status"; then
        log_success "后端服务 (HTTP): 正常"
    else
        log_error "后端服务 (HTTP): 异常"
        all_ok=false
    fi
    
    # 验证 HTTPS（如果申请了 SSL）
    if [ "$SKIP_SSL" != "true" ]; then
        log_info "验证 HTTPS..."
        sleep 2
        if curl -sk "https://$SERVER_DOMAIN/health" 2>/dev/null | grep -q "ok\|healthy\|status"; then
            log_success "HTTPS: 正常"
        else
            log_warn "HTTPS: 可能还在生效中，请稍后验证"
        fi
    fi
    
    # 显示服务状态
    log_info "Docker 服务状态:"
    docker ps --format 'table {{.Names}}\t{{.Status}}\t{{.Ports}}' 2>/dev/null || true
    
    if [ "$all_ok" = true ]; then
        log_success "部署验证通过"
    else
        log_warn "部分服务可能存在问题，请检查日志"
    fi
}

#===============================================================================
# 清理
#===============================================================================

cleanup() {
    log_info "清理临时文件..."
    rm -f "$SCRIPT_DIR/deploy-package.tar.gz" 2>/dev/null || true
    log_success "清理完成"
}

#===============================================================================
# 主流程
#===============================================================================

main() {
    echo -e "${CYAN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║              服务器端一键部署脚本                             ║"
    echo "║     Docker部署 → SSL证书 → Cloudflare Pages                   ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    
    # 解析参数
    parse_args "$@"
    
    # 加载配置
    load_deploy_config
    
    # 验证配置
    validate_config
    
    # 显示配置摘要
    echo ""
    log_info "部署配置:"
    echo "  域名: $SERVER_DOMAIN"
    echo "  邮箱: $SERVER_EMAIL"
    [ -n "$PACKAGE_URL" ] && echo "  部署包: $PACKAGE_URL"
    echo "  前端项目: $CF_PROJECT_UTOLUCK, $CF_PROJECT_COINTOUSDT, $CF_PROJECT_ADMIN"
    echo ""
    echo "部署流程:"
    [ -n "$PACKAGE_URL" ] && echo "  阶段0: 下载并解压部署包"
    echo "  阶段1: 检查/安装 Docker"
    echo "  阶段2: 部署后端服务 (Docker Compose)"
    echo "  阶段3: 申请 SSL 证书"
    echo "  阶段4: 部署 Cloudflare Pages"
    echo "  阶段5: 验证部署"
    echo ""
    
    # 确认
    if [ "$AUTO_YES" != "true" ]; then
        read -p "确认开始部署? [Y/n] " -n 1 -r
        echo
        if [[ ! $REPLY =~ ^[Yy]?$ ]]; then
            log_info "已取消"
            exit 0
        fi
    fi
    
    # 记录开始时间
    START_TIME=$(date +%s)
    
    # 执行部署
    download_and_extract      # 阶段0: 下载并解压部署包
    check_docker              # 阶段1: 检查Docker环境
    deploy_backend            # 阶段2: 部署后端服务
    apply_ssl                 # 阶段3: 申请SSL证书
    deploy_cloudflare_pages   # 阶段4: 部署Cloudflare Pages
    verify_deployment         # 阶段5: 验证部署
    cleanup                   # 清理
    
    # 计算耗时
    END_TIME=$(date +%s)
    DURATION=$((END_TIME - START_TIME))
    MINUTES=$((DURATION / 60))
    SECONDS=$((DURATION % 60))
    
    # 完成
    echo ""
    echo -e "${GREEN}"
    echo "╔═══════════════════════════════════════════════════════════════╗"
    echo "║                      部署完成!                                ║"
    echo "╚═══════════════════════════════════════════════════════════════╝"
    echo -e "${NC}"
    echo ""
    echo "  后端地址:     https://$SERVER_DOMAIN"
    echo ""
    echo "  前端地址 (真实部署URL):"
    # 使用真实URL（如果有），否则使用默认URL
    if [ -n "$DEPLOYED_URL_UTOLUCK" ]; then
        echo "    uToLuck:      $DEPLOYED_URL_UTOLUCK"
    else
        echo "    uToLuck:      https://${CF_PROJECT_UTOLUCK}.pages.dev"
    fi
    if [ -n "$DEPLOYED_URL_COINTOUSDT" ]; then
        echo "    CoinToUsdt:   $DEPLOYED_URL_COINTOUSDT"
    else
        echo "    CoinToUsdt:   https://${CF_PROJECT_COINTOUSDT}.pages.dev"
    fi
    if [ -n "$DEPLOYED_URL_ADMIN" ]; then
        echo "    管理后台:     $DEPLOYED_URL_ADMIN"
    else
        echo "    管理后台:     https://${CF_PROJECT_ADMIN}.pages.dev"
    fi
    echo ""
    echo "  总耗时: ${MINUTES}分${SECONDS}秒"
    echo ""
    echo "  查看日志: docker logs -f web"
    echo ""
}

# 执行主流程
main "$@"
